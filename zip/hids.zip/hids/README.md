# HIDS

Para ejecutar el HIDS, nos posicionamos en el directorio src y ejecutamos el siguiente comando:

`javac mainClass.java && java mainClass`
